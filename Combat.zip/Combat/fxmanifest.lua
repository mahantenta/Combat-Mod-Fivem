-- By Mahan_Tnta

fx_version 'cerulean'
game 'gta5'

author 'Mahan_Tnta'
description 'Combat Mode By Tnta'
version '1.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}