-- By Mahan_Tnta

local inCombat = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        if IsPedShooting(ped) then
            local x, y, z = table.unpack(GetEntityCoords(ped))
            TriggerServerEvent('combat:playerShot', x, y, z)
        end
    end
end)

RegisterNetEvent('combat:startTimer')
AddEventHandler('combat:startTimer', function(time)
    SendNUIMessage({action = 'startCombat', time = time})
end)
