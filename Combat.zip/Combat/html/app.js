let combatTimer = null;
let timeLeft = 0;
let inCombat = false;

$('.texts').hide();

function startCombatMode(time) {
    if (!inCombat) {
        inCombat = true;
        $('.texts').fadeIn(200);
        timeLeft = time / 1000;
        updateTimer();

        combatTimer = setInterval(() => {
            timeLeft--;
            updateTimer();

            if (timeLeft <= 0) {
                clearInterval(combatTimer);
                $('.texts').fadeOut(200);
                inCombat = false;
            }
        }, 1000);
    }
}

function updateTimer() {
    const min = Math.floor(timeLeft / 60);
    const sec = timeLeft % 60;
    $('#timer').text(`${min.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`);
}

window.addEventListener('message', (event) => {
    if(event.data.action === 'startCombat') {
        startCombatMode(event.data.time);
    }
});
