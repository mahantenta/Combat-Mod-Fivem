-- By Mahan_Tnta

ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('combat:playerShot')
AddEventHandler('combat:playerShot', function(x, y, z)
    local _src = source
    local players = ESX.GetPlayers()

    for i=1, #players, 1 do
        local target = players[i]
        local ped = GetPlayerPed(target)
        local px, py, pz = table.unpack(GetEntityCoords(ped))
        local dist = #(vector3(x, y, z) - vector3(px, py, pz))
        if dist <= 20.0 or target == _src then
            TriggerClientEvent('combat:startTimer', target, 180000) -- مشتی من گذاشتم رو سه دقیقه
        end
    end
end)